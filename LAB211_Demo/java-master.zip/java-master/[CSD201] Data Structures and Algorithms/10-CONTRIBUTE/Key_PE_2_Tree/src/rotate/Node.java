package rotate;

import dele_by_copy.*;

public class Node {
   int info;
    Node left;
    Node right;
   Node() {
   }
   Node(int x) {
     info=x;
     left=right=null;
   }
}
